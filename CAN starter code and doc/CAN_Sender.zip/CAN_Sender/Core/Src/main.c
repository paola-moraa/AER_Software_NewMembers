#include "main.h"
#include "stm32f0xx_hal.h"
#include <string.h>
#include <stdio.h>
#include <stdarg.h>

/* ---- Handles ---- */
UART_HandleTypeDef huart2;
CAN_HandleTypeDef  hcan;

/* ---- Prototypes ---- */
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_CAN_Init(void);
static void send_can_frame(uint32_t std_id, uint8_t *data, uint8_t dlc);
static void uprintf(const char *fmt, ...);

/* ======================= MAIN ======================= */
int main(void)
{
  HAL_Init();
  SystemClock_Config();     // 48 MHz from HSI48
  MX_GPIO_Init();
  MX_USART2_UART_Init();    // VCP → PuTTY
  MX_CAN_Init();            // CAN on PA11/PA12

  /* Filters aren't required to TRANSMIT, but Cube drivers want a filter configured if RX IRQs are used.
     We'll just configure "accept all" to keep things consistent. */
  CAN_FilterTypeDef filter = {0};
  filter.FilterBank = 0;
  filter.FilterMode = CAN_FILTERMODE_IDMASK;
  filter.FilterScale = CAN_FILTERSCALE_32BIT;
  filter.FilterIdHigh = 0x0000;
  filter.FilterIdLow  = 0x0000;
  filter.FilterMaskIdHigh = 0x0000;
  filter.FilterMaskIdLow  = 0x0000;
  filter.FilterFIFOAssignment = CAN_RX_FIFO0;
  filter.FilterActivation = ENABLE;
  HAL_CAN_ConfigFilter(&hcan, &filter);

  if (HAL_CAN_Start(&hcan) != HAL_OK) {
    uprintf("CAN start failed\r\n");
    Error_Handler();
  }

  uprintf("CAN sender ready (ID 0x123 @ 500k). Sending every 1s...\r\n");

  uint8_t cnt = 0;
  for (;;)
  {
    uint8_t payload[8] = {
      cnt, (uint8_t)(cnt+1), (uint8_t)(cnt+2), (uint8_t)(cnt+3),
      (uint8_t)(cnt+4), (uint8_t)(cnt+5), (uint8_t)(cnt+6), (uint8_t)(cnt+7)
    };

    send_can_frame(0x123, payload, 8);

    uprintf("TX ID:0x123 DLC:8 DATA:");
    for (int i = 0; i < 8; i++) uprintf(" %02X", payload[i]);
    uprintf("\r\n");

    cnt++;
    HAL_Delay(1000);
  }
}

/* ================== Helpers ================== */
static void send_can_frame(uint32_t std_id, uint8_t *data, uint8_t dlc)
{
  CAN_TxHeaderTypeDef txh = {0};
  uint32_t mailbox;

  txh.StdId = std_id;
  txh.ExtId = 0;
  txh.IDE   = CAN_ID_STD;
  txh.RTR   = CAN_RTR_DATA;
  txh.DLC   = dlc;
  txh.TransmitGlobalTime = DISABLE;

  /* Wait if all 3 mailboxes are busy (simple backoff) */
  uint32_t t0 = HAL_GetTick();
  while (HAL_CAN_GetTxMailboxesFreeLevel(&hcan) == 0U)
  {
    if ((HAL_GetTick() - t0) > 10) break; // don’t stall forever
  }

  if (HAL_CAN_AddTxMessage(&hcan, &txh, data, &mailbox) != HAL_OK) {
    uprintf("AddTxMessage failed (bus off or no mailbox)\r\n");
  }
}

/* ===== UART printf ===== */
static void uprintf(const char *fmt, ...)
{
  char buf[128];
  va_list ap; va_start(ap, fmt);
  int n = vsnprintf(buf, sizeof(buf), fmt, ap);
  va_end(ap);
  if (n < 0) return;
  if (n > (int)sizeof(buf)) n = sizeof(buf);
  HAL_UART_Transmit(&huart2, (uint8_t*)buf, (uint16_t)n, HAL_MAX_DELAY);
}

/* ================== Peripheral inits ================= */

/* 48 MHz system clock using HSI48 (F0-safe) */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI48;
  RCC_OscInitStruct.HSI48State     = RCC_HSI48_ON;
  RCC_OscInitStruct.PLL.PLLState   = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) Error_Handler();

  RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK |
                                     RCC_CLOCKTYPE_SYSCLK |
                                     RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_HSI48;
  RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK) Error_Handler();
}

/* GPIO (nothing special needed here) */
static void MX_GPIO_Init(void)
{
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
}

/* USART2 (VCP): PA2=TX (AF1), PA15=RX (AF1) on Nucleo-32 */
static void MX_USART2_UART_Init(void)
{
  huart2.Instance = USART2;
  huart2.Init.BaudRate   = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits   = UART_STOPBITS_1;
  huart2.Init.Parity     = UART_PARITY_NONE;
  huart2.Init.Mode       = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl  = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK) Error_Handler();
}

/* CAN on PA11(CAN_RX)/PA12(CAN_TX) @ 500 kbps (48 MHz clock) */
static void MX_CAN_Init(void)
{
  hcan.Instance = CAN;
  hcan.Init.Prescaler = 6;                 // 48MHz / (6 * (1+13+2)) = 500 kbps
  hcan.Init.Mode = CAN_MODE_NORMAL;
  hcan.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan.Init.TimeSeg1 = CAN_BS1_13TQ;
  hcan.Init.TimeSeg2 = CAN_BS2_2TQ;
  hcan.Init.TimeTriggeredMode = DISABLE;
  hcan.Init.AutoBusOff        = ENABLE;
  hcan.Init.AutoWakeUp        = ENABLE;
  hcan.Init.AutoRetransmission= ENABLE;
  hcan.Init.ReceiveFifoLocked = DISABLE;
  hcan.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan) != HAL_OK) Error_Handler();
}

/* Minimal error handler */
void Error_Handler(void)
{
  __disable_irq();
  while (1) { /* trap here; you can blink LED if desired */ }
}
